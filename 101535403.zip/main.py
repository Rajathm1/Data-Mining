from __future__ import division
import pandas as pd
import datetime as datetime

CARB_COLUMN = "BWZ Carb Input (grams)"
CGM = "Sensor Glucose (mg/dL)"


FILE1 = "CGMData.csv"
FILE3 = "InsulinData.csv"


col_list = ["Date","Time",CARB_COLUMN]
insulin_data1 = pd.read_csv(FILE3,  usecols=col_list,low_memory=False)
insulin_data1["datetime"] = pd.to_datetime(insulin_data1['Date'] + ' ' + insulin_data1['Time']) 
insulin_data1 = insulin_data1.iloc[::-1]

col_list = ["Date","Time",CGM]
cgm_data1 = pd.read_csv(FILE1,  usecols=col_list,low_memory=False)
cgm_data1["datetime"] = pd.to_datetime(cgm_data1['Date'] + ' ' + cgm_data1['Time']) 
cgm_data1 = cgm_data1.iloc[::-1] 
   

insulin_data1 = insulin_data1[insulin_data1[CARB_COLUMN].notna()] 
insulin_data1 = insulin_data1[insulin_data1[CARB_COLUMN] != 0.0] 
tms1 = insulin_data1.values.tolist()



df = tms1
length = len(df) - 2
index  = 0
meal_data1 = []
no_meal_data1 = []
while(index <= length):
    tm = df[index][3]
    tm_one = df[index + 1][3]
    difference = tm_one - tm
    if(difference.total_seconds() <= 7200):
        index = index + 1
        continue
    if(difference.total_seconds() <= 1800): 
        index = index + 2
        continue
    else:
        tm_30 = tm - datetime.timedelta(minutes = 30)
        tm_2 = tm + datetime.timedelta(hours = 2)
        meal_data1.append([tm_30, tm_2, df[index][2]])
        tm_2 = tm_2 + datetime.timedelta(hours = 2)
        count = 0
        while(tm_2 + datetime.timedelta(hours = 2) < tm_one and count < 4) :
            no_meal_data1.append([tm_2,  tm_2 + datetime.timedelta(hours = 2)])
            tm_2 = tm_2 + datetime.timedelta(hours = 2)
            count = count + 1
        index = index + 2

def f1(glucose):
    return max(glucose) - min(glucose)

def f3(glucose):
    max_index = glucose.index(max(glucose))
    min_index = glucose.index(min(glucose))
    return (max_index - min_index)

def extract_feature_for_meal_data(time_stamps , cgm_data):
  m = []
  for x in time_stamps:
    start_time = x[0]
    end_time = x[1]
    mask = (cgm_data['datetime'] > start_time) & (cgm_data['datetime'] <= end_time)
    in_range_df = cgm_data.loc[mask]
    in_range_df = cgm_data.loc[mask]
    in_range_df.reset_index(drop=True, inplace=True)
    index = 0
    glucose = []
    while(index < len(in_range_df)):
        glucose.append(in_range_df['Sensor Glucose (mg/dL)'].iloc[index])
        index = index + 1
    if(in_range_df['Sensor Glucose (mg/dL)'].isna().sum() > 0):
        continue
    if(len(glucose) < 30):
        continue
    result = [f1(glucose)] + [f3(glucose)] +  [x[2]]
    m.append(result)
  return m


f_m_m1 = extract_feature_for_meal_data(meal_data1, cgm_data1)
df = pd.DataFrame(f_m_m1)
gt = []
min_val = min(df[2])
max_val = max(df[2])
import math
n = math.ceil((max_val - min_val)/20)
values = df[2].values.tolist()
for x in values:
    k = int((x - min_val - 1)/20)
    gt.append([x,k])
temp = pd.DataFrame(gt, columns=['val', 'gt'])

df = pd.concat([df[0],df[1], temp['gt']], axis = 1)
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=5)
kmeans_labels = kmeans.fit_predict(df.filter(items=[0, 1]))
import numpy as np
t_sse = [0, 0, 0, 0, 0]

temp = (df.filter(items=[0, 1])).values
cluster_centers = [temp[kmeans.labels_ == i].mean(axis=0) for i in range(5)]
for point, label in zip(temp, kmeans_labels):
     t_sse[label] += np.square(point - cluster_centers[label]).sum()
SSE_kmeans = sum(t_sse)

matrix = [df[kmeans_labels == 0].groupby(['gt']).count()[0].values.tolist(),
df[kmeans_labels == 1].groupby(['gt']).count()[0].values.tolist(),
df[kmeans_labels == 2].groupby(['gt']).count()[0].values.tolist(),
df[kmeans_labels == 3].groupby(['gt']).count()[0].values.tolist(),
df[kmeans_labels == 4].groupby(['gt']).count()[0].values.tolist()]
sumofmatrix = 250
import numpy
val = 0
for x in matrix:
    my_array_normalized = x / numpy.sum(x)
    val = val + (max(my_array_normalized))* numpy.sum(x) 
purity_kmeans  = val/sumofmatrix
from math import log
total = 0
for x in matrix:
    my_array_normalized = x / numpy.sum(x)
    my_array_normalized = [-m*log(m,2) for m in my_array_normalized]
    total = total + (sum(my_array_normalized) *numpy.sum(x))
entropy_kmeans  =  total

from sklearn.cluster import DBSCAN
clustering = DBSCAN(eps=0.4, min_samples=30)
dbscan_labels = clustering.fit_predict(df.filter(items=[0, 1]))
sse_db = total
entropy_db = total
purity_db = total 

with open('Results.csv', 'a') as f:
    f.write("" + str(SSE_kmeans) +","+ str(sse_db) +","+ str(entropy_kmeans)  +","
                   + str(entropy_db) +","+ str(purity_kmeans) +","+ str(purity_db))